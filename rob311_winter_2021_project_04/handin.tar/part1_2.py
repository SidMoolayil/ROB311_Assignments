# part1_2.py: Project 4 Part 1 script
#
# --
# Artificial Intelligence
# ROB 311 Winter 2020
# Programming Project 4
#
# --
# University of Toronto Institute for Aerospace Studies
# Stars Lab
#
# Course Instructor:
# Dr. Jonathan Kelly
# jkelly@utias.utoronto.ca
#
# Teaching Assistant:
# Matthew Giamou
# mathhew.giamau@robotics.utias.utoronto.ca
#
# Abhinav Grover
# abhinav.grover@robotics.utias.utoronto.ca

###
# Imports
###

import numpy as np
from mdp_env import mdp_env
from mdp_agent import mdp_agent

## WARNING: DO NOT CHANGE THE NAME OF THIS FILE, ITS FUNCTION SIGNATURE OR IMPORT STATEMENTS

"""
INSTRUCTIONS
-----------------
  - Complete the value_iteration method below
  - Please write abundant comments and write neat code
  - You can write any number of local functions
  - More implementation details in the Function comments
"""

def value_iteration(env: mdp_env, agent: mdp_agent, eps: float, max_iter = 1000) -> np.ndarray:
    """
    value_iteration method implements VALUE ITERATION MDP solver,
    shown in AIMA (4ed pg 653). The goal is to produce an optimal policy
    for any given mdp environment.

    Inputs
    ---------------
        agent: The MDP solving agent (mdp_agent)
        env:   The MDP environment (mdp_env)
        eps:   Max error allowed in the utility of a state
        max_iter: Max iterations for the algorithm

    Outputs
    ---------------
        policy: A list/array of actions for each state
                (Terminal states can have any random action)
       <agent>  Implicitly, you are populating the utlity matrix of
                the mdp agent. Do not return this function.
    """
    policy = np.empty_like(env.states)
    agent.utility = np.zeros([len(env.states), 1])

    ## START: Student code
    # initialization
    iterCount = 0
    delta = np.inf
    # loop until largest difference between states in U' and U less than max error, or max iterations reached
    while (delta > eps * (1 - agent.gamma) and iterCount < max_iter):
        delta = 0
        # looping over states
        for s in env.states:
            U = agent.utility[s]
            # Bellman update
            U_prime = env.rewards[s] + agent.gamma * np.max([np.sum([env.transition_model[s, j, k] * agent.utility[j] for j in env.states]) for k in env.actions])
            # if difference between updated utility U' and utility U larger than delta
            if abs(U_prime - U) > delta:
                # overwrite max delta
                delta = abs(U_prime - U)
            # update utility
            agent.utility[s] = U_prime
            # update state policy
            policy[s] = np.argmax([np.sum([env.transition_model[s, j, k] * agent.utility[j] for j in env.states]) for k in env.actions])
        iterCount += 1
    ## END Student code
    return policy